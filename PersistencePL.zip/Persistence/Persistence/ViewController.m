//
//  ViewController.m
//  Persistence
//
//  Created by nuko on 2020/6/29.
//  Copyright © 2020 nuko. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSURL *fileURL = [self dataFileURL];
    
    if ([NSFileManager.defaultManager fileExistsAtPath:fileURL.path]) {
        NSArray *array = [NSArray arrayWithContentsOfURL:fileURL];
        if (array) {
            for (int i = 0 ; i < array.count; i++) {
                ((UITextField *)(self.lineFields[i])).text = array[i];
            }
        }
    }
    
    UIApplication *app = UIApplication.sharedApplication;
    if (app) {
        [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(applicationWillResignActive:) name:UIApplicationWillResignActiveNotification object:app];
    }
    
    
    
}

- (void)applicationWillResignActive:(NSNotification *)notification{
    NSURL *fileURL = [self dataFileURL];
    NSArray *array = [self.lineFields valueForKey:@"text"];
    
    NSError *error = nil;
    [array writeToURL:fileURL error:&error];
}

- (NSURL *)dataFileURL{
    NSArray *urls = [NSFileManager.defaultManager URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask];
    NSURL *url = [NSURL fileURLWithPath:@""];
    url = [urls.firstObject URLByAppendingPathComponent:@"data.plist"];
    return url;
}


@end
